---
title: "Layout: More Tag"
excerpt_separator: <!--more-->
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - read more
  - layout
---

This content is before the [excerpt separator tag](http://jekyllrb.com/docs/posts/#post-excerpts).

Additional content before the more tag.

<!--more-->

And this content is after the more tag.